data structure:
tvstudio_brir (N=44100),lab_brir (N=22050),reha_brir  (N=22050)
.fs			1
.inear
	.left	32xN
	.rigth	32xN
.btear
	.left	32xN
	.righ	32xN
.azimuth	32x1
.distance	32x1

measurement details:
Geithain MO-2 speakears were used for all measreuments. All in-the-ear measreuments were conducted with a KEMAR 45BA artificial head with large ears. Behind-the-ear measreuments for tvstudio_brir and reha_brir were conducted with two earthworks M30 microphones and measreuments for lab_brir with a pair of research hearing aids. See reference for further documentation

reference:
Klein, F.; Werner, S.; Chilian, A. and Gadyuchko, M. "Dataset of In-The-Ear and Behind-The-Ear Binaural Room
Impulse used for Spatial Listening with Hearing Implants", 142nd AES Convention E-Brief 326, Berlin, 2017

contact:
florian.klein@tu-ilmenau.de or stephan.werner@tu-ilmenau.de
